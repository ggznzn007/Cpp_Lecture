#pragma once
#include "Chicken.h"
class NeNe : public Chicken {

public:
	NeNe();

	virtual void showWelcom();
	virtual void cooking();
	virtual void delivery();
};