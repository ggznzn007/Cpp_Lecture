#pragma once
#include "Chinese.h"
class WeWorkChina : public Chinese
{
public:
	WeWorkChina();

	virtual void showWelcom();
	virtual void cooking();
	virtual void delivery();
};


